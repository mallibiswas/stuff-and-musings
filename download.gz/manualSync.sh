#!/bin/sh

#python syncInsertUpdate.py config.json '13fd5<ca%0ec97cf1d|1b7fz' 
python mainSyncDB.py config.json '13fd5<ca%0ec97cf1d|1b7fz' 

#python DisplayMethodologyLookup.py config.json '13fd5<ca%0ec97cf1d|1b7fz' 

#python SummarizeCampaignSetupFiles.py config.json '13fd5<ca%0ec97cf1d|1b7fz' 

#python spendingEfficiency.py config.json '13fd5<ca%0ec97cf1d|1b7fz' 

#python hiperfstores.py config.json '13fd5<ca%0ec97cf1d|1b7fz' 
