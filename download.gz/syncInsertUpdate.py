#! /bin/python

import pyodbc
import datetime
import csv
import os
import sys
import json
import numpy as np
import pandas as pd
import requests
import pymssql
import initialize
import databaseMethods 

# read datsource to datastore file mapping
def readDictionary(dictFilename):
    
    with open(dictFilename) as json_file:
        json_data = json.load(json_file)
    
    return json_data 

    
def dataPrepSourceTarget(table, srcSchema, tgtSchema, dateCol, pullType, primaryKey, numdays):
        
    print(".... Running sql on source and target DB")
    
    sourceQueryBase="select * from ["+srcSchema+"].["+table+"]" 
    sourceQueryRef="select "+primaryKey+" from ["+srcSchema+"].["+table+"]" 
    whereClause=" where "+dateCol+" >= getdate() - "+numdays
    targetQueryBase="select "+primaryKey+" from ["+tgtSchema+"].["+table+"]" 

    # queries
    if pullType == "IR": # = Incremental refresh
        sourceQuery = sourceQueryBase+whereClause+";"
        targetQuery = targetQueryBase+";"
    elif pullType == "FR": # = Full refresh
        sourceQuery = sourceQueryBase+";"
        targetQuery = targetQueryBase+";"

    try:
        sourceConn = databaseMethods.openDBConnection('source') # Open connection
        source_df = pd.read_sql(sourceQuery, sourceConn)
        source_pk_df = pd.read_sql(sourceQueryRef, sourceConn) # list of all Primary Keys in source table
        sourceConn.close() # Close connection
    except: # any error here is severe
        e = sys.exc_info()[0]
        print("error in source sql:", sourceQuery)
        print(source_df.head())
        print(e)
        
    try:
        targetConn = databaseMethods.openDBConnection('target') # Open connection
        target_df = pd.read_sql(targetQuery, targetConn)
        targetConn.close() # Close connection
    except:
        e = sys.exc_info()[0]
        print("error in target sql:", targetQuery)
        print(e)
            
    return {'source':source_df, 'target':target_df, 'ref':source_pk_df}


def checkDFsize(df):
    return len(df.index)


def columnExists(colname, df):

    if colname in df.columns:
        return True



def createIncrementalDf (df1, df2, primaryKey, dateCol):

    
    # create df where records in df1 are not in df2
    
    df2 = df2.copy()
    
    df2['inTarget'] = 1 # insert dummy variable to check outer join

    _merge_df = df1.merge(df2, on=[primaryKey], how='left')

    df=_merge_df[_merge_df.inTarget.isnull()]

    df=df.drop('inTarget',1)
    
    # delete dummy columns from output file (df)
    if columnExists(dateCol+"_y", df): 
        df=df.drop([dateCol+"_y"], 1)
        # rename temp columns
        df = df.rename(columns={dateCol+"_x": dateCol})
        
    return df



def dataPrepInsertDeleteFile(source_df, target_df, ref_df, primaryKey, dateCol):
    
    # create file for incremental insert and deletes
        
    if source_df.empty or columnExists(primaryKey, source_df) == False: # if necessary columns do not exist
        print("Cannnot do full refresh missing key ....")
        return
    
    # Create dataset with new records for insertion into target

    insert_df = createIncrementalDf (source_df, target_df, primaryKey, dateCol) # recs in source but not in target
    
    print(".... Creating insert dataset for refresh:", insert_df.shape[0]) # shape[0] give rowcount
            
    # Create dataset with old records for deletion from target

    delete_df = createIncrementalDf (target_df, ref_df, primaryKey, dateCol) # recs in target but not in source
    print(".... Creating delete dataset for refresh:", delete_df.shape[0]) # shape[0] give rowcount

    return {"insert_df" : insert_df, "delete_df" : delete_df}



def loadIncremental (Table, tgtSchema, primaryKey, insert_df, delete_df):


    if not delete_df.empty: 
        databaseMethods.deleteRecs(Table, tgtSchema, primaryKey, delete_df) # delete records in delete_df
    else:   
        print (".... delete df is empty")
        
    if not insert_df.empty: 
        databaseMethods.insertRecs(Table, tgtSchema, insert_df) # insert records from insert_df
    else:
        print (".... insert df is empty")
        
    return


def loadFull (Table, tgtSchema, insert_df):

    if insert_df.empty: 
        print(".... Empty insert dataset - nothing to insert")
        return  
    else:
        databaseMethods.truncateRecs(tgtSchema, Table) # truncate table
        databaseMethods.insertRecs(Table, tgtSchema, insert_df) # insert records from insert_df

    return


def syncTargetTable (Table, srcSchema, tgtSchema, dateCol, pullType, primaryKey, numdays):

    print('>>>> refreshing '+tgtSchema+"."+Table+" <<<<")
    
    # Sync tables will always use incremental refresh on InsertedOn or UpdatedOn fields
    
    # Create source and target datasets
    srctgtdf_dict=dataPrepSourceTarget(Table, srcSchema, tgtSchema, dateCol, pullType, primaryKey, numdays) 
    source_df=srctgtdf_dict["source"]
    target_df=srctgtdf_dict["target"]
    ref_df=srctgtdf_dict["ref"] # list of primary keys in source table
    
    if source_df.empty: 
        print(".... Empty source dataset - nothing to insert")
        return  
    
    if pullType == "IR":
        # Figure out (incremental) insert and delete df
        insrtdeldf_dict = dataPrepInsertDeleteFile (source_df, target_df, ref_df, primaryKey, dateCol)        
        insert_df = insrtdeldf_dict ["insert_df"]
        delete_df = insrtdeldf_dict ["delete_df"]        
        loadIncremental (Table, tgtSchema, primaryKey, insert_df, delete_df)
    elif pullType == "FR":
        loadFull (Table, tgtSchema, source_df) # insert the source file for full refresh
    else:
        print ("not valid pulltype")
        
        
    return 'ok'


def initializeSync (paramFile):
        
    for i in range (0,len(paramFile["syncTable"])):
    
        tableName      = paramFile["syncTable"][i]["tableName"]
        sourceSchema   = paramFile["syncTable"][i]["sourceSchema"]
        targetSchema   = paramFile["syncTable"][i]["targetSchema"]
        dateField      = paramFile["syncTable"][i]["dateField"]
        pullType       = paramFile["syncTable"][i]["pullType"]
        primaryKey     = paramFile["syncTable"][i]["primaryKey"]
        lookbackDays   = paramFile["syncTable"][i]["lookbackDays"]        
         
        # tablename, source schema, target schema, Date Field, pull Type, Primary Key, identity Insert, Lookback days
        syncTargetTable (tableName, sourceSchema, targetSchema, dateField, pullType, primaryKey, lookbackDays)
            
    
    return

