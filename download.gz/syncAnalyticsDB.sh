#!/bin/sh

fileExt=$(date +%Y%m%d_%H:%M:%S)
logPath=$HOME/scripts/prod/ETL/log
scriptPath=$HOME/scripts/prod/ETL
binPath=$HOME/anaconda3/bin
syncDBScript=mainSyncDB.py
methodologyScript=DisplayMethodologyLookup.py
campaignSetupScript=SummarizeCampaignSetupFiles.py
hiperfStoresScript=hiperfstores.py
logFile=syncDB_$fileExt.log  
configFile=$scriptPath/config.json
decryptKey='13fd5<ca%0ec97cf1d|1b7fz'
statusFile=$HOME/scripts/prod/MAIN/data/JOBS/KF_jobStatus.csv


#
# Create user seat info from KF
#


echo '>>>>' begin sync analytics DB on $(date) > $logPath/$logFile

starttm=$(date +%x:%T)
$binPath/python $scriptPath/$syncDBScript $configFile  $decryptKey  >> $logPath/$logFile 
rc1=$?
endtm=$(date +%x:%T)
echo 'sync DB',$syncDBScript,$starttm,$endtm,$rc1 >> $statusFile

starttm=$(date +%x:%T)
$binPath/python $scriptPath/$methodologyScript $configFile  $decryptKey  >> $logPath/$logFile 
rc2=$?
endtm=$(date +%x:%T)
echo 'Methodology',$methodologyScript,$starttm,$endtm,$rc2 >> $statusFile

starttm=$(date +%x:%T)
$binPath/python $scriptPath/$hiperfStoresScript $configFile  $decryptKey  >> $logPath/$logFile 
rc3=$?
endtm=$(date +%x:%T)
echo 'HiPerfStores',$hiperfStoresScript,$starttm,$endtm,$rc3 >> $statusFile

starttm=$(date +%x:%T)
$binPath/python $scriptPath/$campaignSetupScript $configFile  $decryptKey  >> $logPath/$logFile 
rc4=$?
endtm=$(date +%x:%T)
echo 'Campaign Setup',$campaignSetupScript,$starttm,$endtm,$rc4 >> $statusFile

exit 
